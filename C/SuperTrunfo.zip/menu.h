#ifndef MENU_H
#define MENU_H

void menuJogo();

#endif