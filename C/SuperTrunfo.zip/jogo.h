#ifndef JOGO_H
#define JOGO_H

#include "usuario.h"

void inicio();
void jogarComUsuario(int index);

#endif // JOGO_H
