#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "usuario.h"
#include "jogo.h"
#include "menu.h"

int main(void) {
    menuJogo();
    return 0;
}

